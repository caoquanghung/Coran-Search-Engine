# VnSearch — Text Search Engine

**Student:** Cao Quang Hung  
**Student ID:** 24125010

VnSearch is a Vietnamese text search engine built with Whoosh and Streamlit. It crawls VnExpress articles, creates a persistent inverted index, and presents matching documents in a Google-style interface.

## Main Features

- Crawls VnExpress articles from multiple categories and pages.
- Stores a dataset containing the 100 candidate articles with the highest comment counts.
- Indexes article titles, descriptions, and content with Whoosh.
- Uses BM25F ranking, with higher weights for titles and descriptions.
- Supports Vietnamese queries with or without diacritics.
- Displays the URL, title, highlighted snippet, publication date, category, and comment count for each result.
- Supports pagination and sorting by relevance or comment count.
- Loads related images lazily and caches them for one hour.
- Stores the Whoosh index on disk so the dataset is not re-indexed after every Streamlit interaction.

## Requirements

- Python 3.10 or newer
- The Python packages listed in `requirements.txt`

## Installation

Open a terminal in the `24125010` folder and run:

```bash
python -m venv .venv

# macOS or Linux
source .venv/bin/activate

# Windows PowerShell
# .venv\Scripts\Activate.ps1

pip install -r requirements.txt
```

## Running the Application

The submitted package already contains the crawled dataset and a persistent Whoosh index. Start the graphical interface with:

```bash
streamlit run main.py
```

Streamlit will display a local URL, normally `http://localhost:8501`.

## Persistent Indexing

The application checks whether a valid index already exists in the `index/` directory. If it exists, `SearchService` opens and reuses it. Streamlit's `st.cache_resource` also keeps the search service available across interface reruns.

The index is created only when no valid index exists and `data/documents.jsonl` is available. Therefore, entering a query, changing the sort option, or moving between result pages does not rebuild the dataset index.

To rebuild the index manually, run:

```bash
python scripts/build_index.py
```

## Optional: Crawling the Dataset Again

The included dataset is ready to use. To crawl a new dataset and rebuild the index:

```bash
python scripts/crawl.py --limit 100 --pages 5 --candidates 500
python scripts/build_index.py
```

Please use a reasonable crawl delay and follow the source website's terms and robots policy.

## Running the Tests

```bash
pytest -q
```

## Project Structure

```text
24125010/
├── main.py                  # Streamlit graphical interface
├── requirements.txt         # Required Python libraries
├── README.md                # Setup and usage instructions
├── crawler/
│   ├── crawler.py           # Link discovery and article crawling
│   ├── parser.py            # Article content extraction
│   └── image_crawler.py     # Lazy related-image retrieval
├── engine/
│   ├── schema.py            # Whoosh schema and Vietnamese normalization
│   ├── indexer.py           # Persistent index construction
│   └── searcher.py          # Query parsing, BM25F retrieval, and snippets
├── scripts/
│   ├── crawl.py             # Dataset crawling command
│   └── build_index.py       # Index-building command
├── data/
│   ├── documents.jsonl      # Crawled article dataset
│   └── seeds.txt            # Initial category URLs
├── index/                   # Prebuilt persistent Whoosh index
└── tests/                   # Automated tests
```
